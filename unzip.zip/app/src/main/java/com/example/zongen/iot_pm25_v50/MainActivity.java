package com.example.zongen.iot_pm25_v50;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

//Draw
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;

//Time
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Timer;

//Data Catch
import java.net.URL;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;

public class MainActivity extends AppCompatActivity {

    private GraphView mGraphView;
    private TextView PMValue,TempValue,HumValue,TimeValue;
    private Spinner SensorSpinner;
    private ArrayAdapter SensorAdapter;
    private RatingBar AQRatingBar;
    public URL PM_Url,Temp_Url,Hum_Url;
    public int count=0;
    public String SpinnerSelect,sPMValue,sTempValue,sHumValue;
    Thread t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        PMValue = (TextView)findViewById(R.id.PM25Value);
        TempValue = (TextView)findViewById(R.id.TempValue);
        HumValue = (TextView)findViewById(R.id.HumValue);
        TimeValue = (TextView)findViewById(R.id.TimeValue);
        SensorSpinner = (Spinner)findViewById(R.id.spinnerSensor);
        AQRatingBar = (RatingBar)findViewById(R.id.AQratingBar);
        //Draw
        mGraphView = (GraphView) findViewById(R.id.graph);
        mGraphView.setMaxValue(10); //設定圖形數字最大值

        //Sensors Spinner
        //将可选内容与ArrayAdapter连接起来
        SensorAdapter = ArrayAdapter.createFromResource(this, R.array.Sensor, android.R.layout.simple_spinner_item);
        //设置下拉列表的风格
        SensorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //将adapter2 添加到spinner中
        SensorSpinner.setAdapter(SensorAdapter);
        //添加事件Spinner事件监听
        SensorSpinner.setOnItemSelectedListener(new SpinnerSensorSelected());
        //设置默认值
        SensorSpinner.setVisibility(View.VISIBLE);
        //End

        t = new MyThread(); // 產生Thread物件
        t.start();
    }

    //Spinner onItemSelect
    class SpinnerSensorSelected implements AdapterView.OnItemSelectedListener {
        public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,long arg3) {
            String SensorName = SensorAdapter.getItem(arg2).toString();
            try {
                switch (SensorName){
                    case "Sensor1":
                        SpinnerSelect="Sensor1";
                        PM_Url=new URL("http://140.127.196.104:8880/s1_pm");
                        Temp_Url = new URL("http://140.127.196.104:8880/s1_Temp");
                        Hum_Url = new URL("http://140.127.196.104:8880/s1_Hum");
                        break;
                    case "Sensor2":
                        SpinnerSelect="Sensor2";
                        PM_Url=new URL("http://140.127.196.104:8880/s2_pm");
                        Temp_Url = new URL("http://140.127.196.104:8880/s2_Temp");
                        Hum_Url = new URL("http://140.127.196.104:8880/s2_Hum");
                        break;
                    case "Sensor3":
                        SpinnerSelect="Sensor3";
                        PM_Url=new URL("http://140.127.196.104:8880/s3_pm");
                        Temp_Url = new URL("http://140.127.196.104:8880/s3_Temp");
                        Hum_Url = new URL("http://140.127.196.104:8880/s3_Hum");
                        break;
                    case "NA":
                        SpinnerSelect = "NA";
                        break;
                }
            }catch (Exception e){
                SensorSpinner.setSelection(3);
            }
        }
        public void onNothingSelected(AdapterView<?> arg0) {
        }
    }
    //End

    //Data Catch

    public void DataCatch(){
        try {
            if(count == 0){
                count=count+1;

                PM_Url=new URL("http://140.127.196.104:8880/s1_pm");
                Temp_Url = new URL("http://140.127.196.104:8880/s1_Temp");
                Hum_Url = new URL("http://140.127.196.104:8880/s1_Hum");

                Document PMdoc =  Jsoup.parse(PM_Url, 3000);
                Document Tempdoc =  Jsoup.parse(Temp_Url, 3000);
                Document Humdoc =  Jsoup.parse(Hum_Url, 3000);

                Elements PMH1 = PMdoc.select("h1");
                Elements TempH1 = Tempdoc.select("h1");
                Elements HumH1 = Humdoc.select("h1");

                sPMValue = PMH1.text().toString();
                sTempValue = TempH1.text().toString();
                sHumValue = HumH1.text().toString();
            }else {
                Document PMdoc =  Jsoup.parse(PM_Url, 3000);
                Document Tempdoc =  Jsoup.parse(Temp_Url, 3000);
                Document Humdoc =  Jsoup.parse(Hum_Url, 3000);

                Elements PMH1 = PMdoc.select("h1");
                Elements TempH1 = Tempdoc.select("h1");
                Elements HumH1 = Humdoc.select("h1");

                sPMValue = PMH1.text().toString();
                sTempValue = TempH1.text().toString();
                sHumValue = HumH1.text().toString();
            }

            //return sPMValue,sTempValue,sHumValue;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            setPMValue("0");
            setTempValue("0");
            setHumValue("0");
            //return 0;
        }
    }
    //End

    //Temp Data Catch
/*    public int Temp_DataCatch(){
        try {
            Document doc =  Jsoup.parse(Temp_Url, 3000);
            Elements H1 = doc.select("h1");
            int intPMValue = Integer.parseInt(H1.text());
            return intPMValue;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            setPMValue("0");
            return 0;
        }
    }*/
    //End

    //Hum Data Catch
/*    public int Hum_DataCatch(){
        try {
            Document doc =  Jsoup.parse(Hum_Url, 3000);        //連結該網址
            Elements H1 = doc.select("h1");
            int intPMValue = Integer.parseInt(H1.text());
            return intPMValue;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            setPMValue("0");
            return 0;
        }
    }*/
    //End

    //Draw
    class MyThread extends Thread {
        public void run() {
            super.run();
            try {
                mGraphView.setMaxValue(1000);   //設置繪圖Y最大1000
                int mInput;
                do {
                    if(SpinnerSelect == "NA"){
                        mInput = 0;

                        final int reading = mInput;
                        addPoint(reading); // 畫線

                        setPMValue("0");

                        setTempValue("0");

                        setHumValue("0");

                        SetAQRatingBar(mInput);

                        setTimeValue(getDateTime());

                        sleep(1000); // 暫停100ms
                    }else {
                        DataCatch();

                        mInput = Integer.parseInt(sPMValue); // 呼叫抓值

                        final int reading = mInput;
                        addPoint(reading); // 畫線

                        setPMValue(sPMValue);

                        setTempValue(sTempValue);

                        setHumValue(sHumValue);

                        SetAQRatingBar(mInput);

                        setTimeValue(getDateTime());

                        sleep(1000); // 暫停100ms
                    }

                } while (MainActivity.MyThread.interrupted() == false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    //Set Air Quality Bar
    public void SetAQRatingBar(final int pmvalue){
        if(pmvalue<75){
            AQRatingBar.setRating(5);
        }else if (pmvalue > 75 && pmvalue < 150){
            AQRatingBar.setRating(4);
        }else if (pmvalue > 150 && pmvalue < 300){
            AQRatingBar.setRating(3);
        }else if (pmvalue > 300 && pmvalue < 1050){
            AQRatingBar.setRating(2);
        }else if (pmvalue > 1050 && pmvalue < 3000){
            AQRatingBar.setRating(1);
        }else if (pmvalue > 3000){
            AQRatingBar.setRating(0);
        }

    }
    //End

    // 畫線
    private void addPoint(final float point) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mGraphView.addDataPoint(point);
            }
        });
    }
    //End

    // PMValue
    private void setPMValue(final String pm){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                PMValue.setText(pm);
            }
        });
    }

    //TempValue
    private void setTempValue(final String temp){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                TempValue.setText(temp);
            }
        });
    }

    // HumValue
    private void setHumValue(final String Hum){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                HumValue.setText(Hum);
            }
        });
    }

    //Time
    private void setTimeValue(final String time){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                TimeValue.setText(time);
            }
        });
    }
    public String getDateTime(){
        SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
        Date date = new Date();
        String strDate = sdFormat.format(date);
        return strDate;
    }
    //Time End
}
